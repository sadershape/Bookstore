// DOM Elements
const loginBtn = document.getElementById('login-btn');
const logoutBtn = document.getElementById('logout-btn');
const usernameInput = document.getElementById('username');
const usernameDisplay = document.getElementById('username-display');
const themeToggle = document.getElementById('theme-toggle');
const currentTimeDisplay = document.getElementById('current-time');
const starElements = document.querySelectorAll('.star');

// Load user preferences and ratings from localStorage
window.onload = function () {
    const username = localStorage.getItem('username');
    const theme = localStorage.getItem('theme');
    const time = new Date().toLocaleTimeString();

    // Set the current time
    currentTimeDisplay.textContent = time;

    // Load the theme preference
    if (theme === 'dark') {
        document.body.classList.add('dark-theme');
        themeToggle.textContent = 'Light Mode';
    }

    // If user is logged in, show their username
    if (username) {
        usernameDisplay.textContent = `Welcome, ${username}`;
        usernameInput.style.display = 'none'; // Hide the input when logged in
        loginBtn.style.display = 'none'; // Hide login button when logged in
        logoutBtn.style.display = 'block'; // Show logout button
        loadUserRatings(username); // Load ratings for this user
    }
};

// Login Functionality
loginBtn.addEventListener('click', () => {
    const username = usernameInput.value.trim();
    if (username) {
        localStorage.setItem('username', username);
        usernameDisplay.textContent = `Welcome, ${username}`;
        usernameInput.style.display = 'none';
        loginBtn.style.display = 'none';
        logoutBtn.style.display = 'block';
        loadUserRatings(username); // Load ratings for this user
    }
});

// Logout Functionality
logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('username');
    usernameDisplay.textContent = '';
    usernameInput.style.display = 'inline-block';
    loginBtn.style.display = 'inline-block';
    logoutBtn.style.display = 'none';
    clearUserRatings(); // Clear ratings when logging out
});

// Theme Toggle Functionality
themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
    const theme = document.body.classList.contains('dark-theme') ? 'dark' : 'light';
    localStorage.setItem('theme', theme);
    themeToggle.textContent = theme === 'dark' ? 'Light Mode' : 'Dark Mode';
});

// Update current time every second
setInterval(() => {
    currentTimeDisplay.textContent = new Date().toLocaleTimeString();
}, 1000);

// Star Rating Functionality
starElements.forEach(star => {
    star.addEventListener('click', (event) => {
        const selectedRating = event.target.getAttribute('data-value');
        const bookCard = event.target.closest('.card');
        const bookTitle = bookCard.querySelector('.card-title').textContent;
        const username = localStorage.getItem('username');

        if (username) {
            saveRating(username, bookTitle, selectedRating);
            updateStarRating(bookCard, selectedRating);
        } else {
            alert('Please log in to rate books.');
        }
    });
});

// Function to save rating in localStorage
function saveRating(username, bookTitle, rating) {
    const ratings = JSON.parse(localStorage.getItem('ratings')) || {};
    if (!ratings[username]) {
        ratings[username] = {};
    }
    ratings[username][bookTitle] = rating;
    localStorage.setItem('ratings', JSON.stringify(ratings));
}


// Function to load user ratings
function loadRatings() {
    const username = localStorage.getItem('username');
    if (username) {
        const ratings = JSON.parse(localStorage.getItem('ratings'));
        if (ratings && ratings[username]) {
            for (const [bookTitle, rating] of Object.entries(ratings[username])) {
                const bookCard = Array.from(document.querySelectorAll('.card')).find(card => {
                    return card.querySelector('.card-title').textContent === bookTitle;
                });
                if (bookCard) {
                    updateStarRating(bookCard, rating);
                }
            }
        }
    }
}
// Function to update the star rating display with glowing effect
function updateStarRating(bookCard, rating) {
    const stars = bookCard.querySelectorAll('.star');
    stars.forEach(star => {
        star.classList.remove('selected'); // Clear previous ratings
        if (parseInt(star.getAttribute('data-value')) <= rating) {
            star.classList.add('selected'); // Highlight stars equal to or less than the rating
        }
    });
}

// Clear user ratings when logged out
function clearUserRatings() {
    const userRatings = JSON.parse(localStorage.getItem('userRatings')) || {};
    const username = localStorage.getItem('username');
    if (userRatings[username]) {
        delete userRatings[username];
        localStorage.setItem('userRatings', JSON.stringify(userRatings));
    }
}

document.addEventListener('DOMContentLoaded', loadRatings);
